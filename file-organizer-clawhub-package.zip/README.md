# 📁 智能文件整理器 (File Organizer)

## 🌟 产品简介
**智能文件整理器**是一款基于OpenClaw的AI助手技能，能够自动分类、重命名、整理电脑文件，解决文件混乱问题。

## 🎯 核心功能

### 1. 智能分类整理
- **按类型分类**：文档、图片、视频、音频、压缩包等
- **按时间整理**：按年/月/日自动归档
- **智能识别**：自动识别文件内容并分类

### 2. 批量重命名
- **序列重命名**：file_001, file_002...
- **时间戳重命名**：20240301_文档.pdf
- **内容重命名**：从文件内容提取关键词

### 3. 重复文件检测
- **精确检测**：MD5哈希校验
- **空间回收**：找出重复文件节省空间

### 4. 清理优化
- **空文件夹清理**：删除空文件夹
- **临时文件清理**：清理系统临时文件
- **大文件查找**：找出占用空间的大文件

## 🚀 性能特点
- **高速处理**：1759+ 文件/秒
- **跨平台**：Windows、Linux、macOS全兼容
- **智能缓存**：优化内存使用
- **安全可靠**：操作前备份，错误恢复

## 📦 安装方法

### 通过ClawHub安装
```bash
npx clawhub install file-organizer
```

### 手动安装
1. 下载技能包
2. 复制到OpenClaw技能目录：`~/.openclaw/workspace/skills/`
3. 重启OpenClaw网关

## 🛠 使用方法

### 基本命令
```bash
# 整理指定文件夹
openclaw file-organizer organize --path "~/Downloads"

# 批量重命名
openclaw file-organizer rename --pattern "photo_{num}.jpg"

# 查找重复文件
openclaw file-organizer find-duplicates
```

### 配置示例
```yaml
file_organizer:
  rules:
    documents: ['.pdf', '.doc', '.docx', '.txt']
    images: ['.jpg', '.png', '.gif', '.bmp']
  actions:
    move_to_categories: true
    create_backup: true
```

## 📊 测试结果
- **整理测试**：✅ 通过 (0.02秒处理21个文件)
- **重命名测试**：✅ 通过 (0.01秒重命名10个文件)
- **重复检测测试**：✅ 通过 (精确MD5校验)
- **性能测试**：✅ **优秀** (1759.1文件/秒)

## 🤝 贡献指南
欢迎提交Issue和Pull Request！

## 📄 许可证
MIT License

## 🔗 相关链接
- GitHub仓库：https://github.com/chuanwen0901/smart-file-organizer
- 问题反馈：GitHub Issues
- 作者：chuanwen0901