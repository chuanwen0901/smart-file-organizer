# 📦 智能文件整理器 - 安装指南

## 方法一：通过GitHub直接安装

### 步骤1：下载技能包
```bash
# 从GitHub下载最新版本
curl -L -o file-organizer.zip https://github.com/chuanwen0901/smart-file-organizer/archive/refs/heads/main.zip
```

### 步骤2：解压并安装
```bash
# 解压文件
unzip file-organizer.zip

# 复制到OpenClaw技能目录
cp -r smart-file-organizer-main/skill ~/.openclaw/workspace/skills/file-organizer
```

### 步骤3：重启OpenClaw
```bash
# 重启OpenClaw网关
openclaw gateway restart
```

## 方法二：手动安装

### Windows系统
1. 下载技能包：`file-organizer-v1.0.0-20260301.zip`
2. 解压到：`C:\Users\[用户名]\.openclaw\workspace\skills\file-organizer\`
3. 重启OpenClaw服务

### Linux/macOS系统
```bash
# 创建技能目录
mkdir -p ~/.openclaw/workspace/skills/file-organizer

# 复制文件
cp organizer.py ~/.openclaw/workspace/skills/file-organizer/
cp SKILL.md ~/.openclaw/workspace/skills/file-organizer/

# 设置权限
chmod +x ~/.openclaw/workspace/skills/file-organizer/organizer.py
```

## 方法三：使用安装脚本

### Windows
```bash
# 运行安装脚本
install.bat
```

### Linux/macOS
```bash
# 运行安装脚本
chmod +x install.sh
./install.sh
```

## 验证安装

### 检查技能是否加载
```bash
openclaw skills list | grep file-organizer
```

### 测试技能功能
```bash
# 测试整理功能
openclaw file-organizer organize --path ~/Downloads --test

# 测试重命名功能
openclaw file-organizer rename --pattern "test_{num}" --count 5
```

## 故障排除

### 常见问题

#### 1. 技能未显示在列表中
- 检查技能目录路径是否正确
- 确保SKILL.md文件存在
- 重启OpenClaw网关

#### 2. 权限错误
- Windows：以管理员身份运行
- Linux/macOS：使用sudo或调整文件权限

#### 3. Python依赖问题
```bash
# 安装Python依赖
pip install hashlib datetime os shutil
```

#### 4. 性能问题
- 确保有足够的内存
- 分批处理大文件夹
- 使用`--limit`参数限制文件数量

## 更新技能

### 从GitHub更新
```bash
# 下载最新版本
curl -L -o file-organizer.zip https://github.com/chuanwen0901/smart-file-organizer/archive/refs/heads/main.zip

# 备份旧版本
mv ~/.openclaw/workspace/skills/file-organizer ~/.openclaw/workspace/skills/file-organizer.backup

# 安装新版本
unzip file-organizer.zip
cp -r smart-file-organizer-main/skill ~/.openclaw/workspace/skills/file-organizer
```

## 卸载技能

### 完全卸载
```bash
# 删除技能目录
rm -rf ~/.openclaw/workspace/skills/file-organizer

# 重启OpenClaw
openclaw gateway restart
```

## 支持与反馈

- **GitHub Issues**: https://github.com/chuanwen0901/smart-file-organizer/issues
- **功能请求**: 通过GitHub提交
- **Bug报告**: 包含详细错误信息和系统环境

## 版本历史

### v1.0.0 (2026-03-01)
- 初始发布版本
- 智能文件分类
- 批量重命名
- 重复文件检测
- 空文件夹清理
- 跨平台支持

---

**注意**: 本技能为开源项目，遵循MIT许可证。使用前请阅读LICENSE文件。